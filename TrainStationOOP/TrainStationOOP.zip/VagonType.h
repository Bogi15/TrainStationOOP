#pragma once
enum class VagonType 
{
	firstClass = 1,
	secondClass = 2,
	sleeping = 3
};

