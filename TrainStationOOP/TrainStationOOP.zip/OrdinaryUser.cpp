#include "OrdinaryUser.h"

void OrdinaryUser::writeBinary(std::ofstream& ofs) const
{
}

void OrdinaryUser::readBinary(std::ifstream& ifs)
{
}
