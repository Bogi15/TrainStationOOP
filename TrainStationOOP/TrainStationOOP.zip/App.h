#pragma once
#include "CommandExecutor.h"
class App
{
public:
	void run();
};

