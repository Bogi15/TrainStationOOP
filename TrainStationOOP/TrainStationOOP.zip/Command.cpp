#include "Command.h"

Command::Command(systemManager* m)
{
	this->manager = m;
}
