#include "exitCommnad.h"

void exitCommnad::execute() const
{
	
}
